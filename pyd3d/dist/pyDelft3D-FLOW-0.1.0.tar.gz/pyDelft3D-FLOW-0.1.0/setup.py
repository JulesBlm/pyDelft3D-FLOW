# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pyd3d',
 'pyd3d..ipynb_checkpoints',
 'pyd3d.input',
 'pyd3d.input..ipynb_checkpoints',
 'pyd3d.output']

package_data = \
{'': ['*'], 'pyd3d': ['.vscode/*']}

install_requires = \
['bezier>=2020.5.19,<2021.0.0',
 'cmocean>=2.0,<3.0',
 'colorcet>=2.0.2,<3.0.0',
 'dask[dataframe]>=2.11.0,<3.0.0',
 'datashader>=0.11.0,<0.12.0',
 'holoviews>=1.12.7,<2.0.0',
 'hvplot>=0.6.0,<0.7.0',
 'imageio-ffmpeg>=0.4.2,<0.5.0',
 'ipympl>=0.5.2,<0.6.0',
 'jupyterlab>=2.1.4,<3.0.0',
 'matplotlib>=3.1.3,<4.0.0',
 'netcdf4>=1.5.3,<2.0.0',
 'numpy>=1.18.5,<2.0.0',
 'pandas>=1.0.4,<2.0.0',
 'pyvista>=0.25.3,<0.26.0',
 'widgetsnbextension>=3.5.1,<4.0.0',
 'xarray>=0.15.1,<0.16.0']

setup_kwargs = {
    'name': 'pydelft3d-flow',
    'version': '0.1.0',
    'description': 'Python tools to manipulate Delft3D(4)-FLOW input and output',
    'long_description': None,
    'author': 'JulesBlm',
    'author_email': 'julesblom@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)

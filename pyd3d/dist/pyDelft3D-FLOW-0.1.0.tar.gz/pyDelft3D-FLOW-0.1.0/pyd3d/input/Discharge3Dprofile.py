# now the rest from that notebook
from decimal import Decimal

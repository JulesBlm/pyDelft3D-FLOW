# now the rest from that notebook
from decimal import Decimal
import os
import numpy as np
from .utils import formatSci
from .mdf import Mdf
from IPython.display import Markdown as md
import pandas as pd
from decimal import Decimal
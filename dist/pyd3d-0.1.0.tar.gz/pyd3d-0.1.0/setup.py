# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pyd3d', 'pyd3d.input', 'pyd3d.output']

package_data = \
{'': ['*'], 'pyd3d': ['dist/*']}

install_requires = \
['bezier>=2020.5.19,<2021.0.0',
 'cmocean>=2.0,<3.0',
 'colorcet>=2.0.2,<3.0.0',
 'dask[dataframe]>=2.11.0,<3.0.0',
 'datashader>=0.11.0,<0.12.0',
 'holoviews>=1.12.7,<2.0.0',
 'hvplot>=0.6.0,<0.7.0',
 'imageio-ffmpeg>=0.4.2,<0.5.0',
 'ipympl>=0.5.2,<0.6.0',
 'jupyterlab>=2.1.4,<3.0.0',
 'matplotlib>=3.1.3,<4.0.0',
 'netcdf4>=1.5.3,<2.0.0',
 'numpy>=1.18.5,<2.0.0',
 'pandas>=1.0.4,<2.0.0',
 'pyvista>=0.25.3,<0.26.0',
 'widgetsnbextension>=3.5.1,<4.0.0',
 'xarray>=0.15.1,<0.16.0']

extras_require = \
{'itk': ['itkwidgets>=0.29.0,<0.30.0']}

setup_kwargs = {
    'name': 'pyd3d',
    'version': '0.1.0',
    'description': 'Python tools to manipulate Delft3D(4)-FLOW input and output',
    'long_description': '# pyDelft3D-FLOW\n\npyDelft3D-FLOW is a small Python package that were developed to help with 1) reading and writing of several input files of a [Delft3D4-FLOW model](https://oss.deltares.nl/documents/183920/185723/Delft3D-FLOW_User_Manual.pdf), 2) auto-generating multiple successive runs, 3) (interactive) plotting of the Delft3D-FLOW output (NetCDF format only) as and 4) overwriting values in NetCDF output. \n\nI will attempt to make [everything I developed for my thesis](https://github.com/JulesBlm/Delft3D-Python-Thesis) to a clean and reusable package here. Check out the notebook to get up-and-running.\n\n## Installation\n\nInstall pyDelft3D-FLOW with [Poetry](https://python-poetry.org/docs/) (preferred) or Conda.\n\n### Python Poetry\n\n[Why poetry?](https://hackersandslackers.com/python-poetry-package-manager/)\n\nRun `poetry install`.\n\n\n### Conda\n\nMake a Python environment with [Anaconda](https://www.anaconda.com/products/individual), [Miniconda](https://docs.conda.io/en/latest/miniconda.html), [Poetry](https://python-poetry.org/) or whatever you like.\n\nThere are three commands to run after installation to get the widgets and plot figures to play nicely with JupyterLab\n\n### JupyterLab\n\n1. To get [ipywidgets](https://ipywidgets.readthedocs.io/en/latest/user_install.html) working run the following two commands\n\n```bash\njupyter nbextension enable --py widgetsnbextension\n\njupyter labextension install @jupyter-widgets/jupyterlab-manager jupyter-matplotlib@\n```\n\n2. To get matplotlib plots working nicely in JupyterLab run the following command after installing\n\n```bash\njupyter labextension install @jupyter-widgets/jupyterlab-manager\n```\n\n3. To get [HoloViews](http://holoviews.org/) widgets working properly in JupyterLab, run\n\n```bash\njupyter labextension install @pyviz/jupyterlab_pyviz\n```\n\n4. (Optional) to get [ITKwidgets](https://github.com/InsightSoftwareConsortium/itkwidgets#installation) working, run the following command after the previous ones\n\n```bash\njupyter labextension install jupyterlab-datawidgets itkwidgets\n```\n\n## Viewing Output\n\nThe scripts were developed with a focus on modelling sequential turbidity currents in Delft3D-FLOW, so the focus is on 3D models and cross-section of the 3D output. However, the scripts are valuable for any type of Delft3D(4)-FLOW output.\n\n### xarray\nThe core functionality is provided by [xarray](https://xarray.pydata.org/). Delft3D-FLOW writes output in the NetCDF3 64-bit format with metadata following the [Climate & Forecast Conventions](http://cfconventions.org/).\nxarray is Python package for opening and analysing multidimensional gridded data sets. xarray is particularly tailored to working with self-describing NetCDF files and has native support for CF convention metadata, like that written by Delft3D-FLOW.\nxarray introduces labels in the form of dimensions, coordinates and attributes on top of raw multidimensional arrays, which allows for a more intuitive, more concise, and less error-prone developer experience.\n\nxarray integrates tightly with [Dask](https://dask.org/) under the hood to facilitate out-of-memory and parallel computations on large datasets that do not fit into memory. Dask arrays allow handling very large array operations using many small arrays known as *chunks*. This enables many successive simulations to be combined and opened as one dataset.\n\n### HoloViews/hvPlot\n[HoloViews](http://holoviews.org/) is a a Python library that enables visual exploration of multi-dimensional parameter spaces using auto-generated widgets that read the datasets metadata. Thanks to built-in Dask and Datashader integration HoloViews scales easily to millions of datapoints. hvPlot is a convenience wrapper around xarray for plotting data with HoloViews for more advanced, interactive visualizations.\n\n\n### Three-dimensional\n\n[PyVista](https://www.pyvista.org/) is a pure Python library wrapping the [VTK library](https://vtk.org)\'s Python bindings for a streamlined and intuitive toolset for 3D Visualization and mesh analysis and processing. PyVista can be used across platforms, has extensive documentation and is open-source with a permissive MIT Licence. Structures created in PyVista are immediately interoperable with any VTK-based software.\n\nOptionally, install [ITKwidgets](https://docs.pyvista.org/plotting/itk_plotting.html) to interactively visualize a PyVista mesh within a Jupyter notebook\n\n`poetry install --extras "itk"`\n\n\n# Prior Work\n\n* [https://github.com/Carlisle345748/Delft3D-Toolbox](Delft3D-Toolbox)\n* [https://github.com/spmls/pydelft](pydelft)\n* [https://svn.oss.deltares.nl/repos/openearthtools/trunk/python/OpenEarthTools/openearthtools/io/delft3d/](Deltares Python OpenEarthTools)\n\n\n# To-do\n\nI\'d like to get to these\n\n* Move colorcet and imageio-ffmpeg to extras\n* Black\n* Proper package with correct imports and all that\n* [Sphinx docs](https://docs.readthedocs.io/en/stable/intro/getting-started-with-sphinx.html) with [RST](https://www.sphinx-doc.org/en/master/usage/restructuredtext/basics.html)\n\n\n# Ideas\n\nI have plenty of ideas for improvement that I most likely won\'t get to.\n\n## Input\n* Automatically read parameters into right types (float, int). For example in Sed.py and Mor.py, everthing is read as a string.\n* Tighter integration with xarray\n* Match read file contents against dict of description so you know what the keywords are for.\n    * Check if selected options are valid\n* Expand D3Dmodel class to include all model\'s information.\n    * Plot all model times in one chart, discharge time, spin-up time, smoothing time\n* Better handling of ensembles of models, ie multiple scenarios.\n* Visualise vertical grid of input files (in 3D).\n    * Visualise 3D vertical boundary profile in 3D\n* Testing\n* Support for unit-aware arrays with [pint](https://pint.readthedocs.io) to define, operate and manipulate physical quantities. Pint is already integrated in xarray, this would be very useful in calculating sediment volumes of in-flow boundary conditions for example.\n\n\n## Output\n* Support for plotting non-uniform grids with enclosures in HoloViews.\n* Out-of-core (lazy) operations for summing vector components like velocity and bottom stress.\n* Efficiently plotting vector fields (quiver plots) without loading the all required data into memory at once.\n* Interactive 3D plotting with [Panel](https://panel.holoviz.org/reference/panes/VTK.html) or [itkwidgets](https://github.com/InsightSoftwareConsortium/itkwidgets)\n\n',
    'author': 'JulesBlm',
    'author_email': 'julesblom@gmail.com',
    'maintainer': 'JulesBlm',
    'maintainer_email': 'julesblom@gmail.com',
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
